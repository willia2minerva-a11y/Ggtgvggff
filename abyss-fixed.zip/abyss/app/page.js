// app/page.js
import Link from 'next/link';
import { getCurrentUser } from '@/lib/auth';
import { dbConnect } from '@/lib/mongodb';
import User from '@/lib/models/User';
import Nav from '@/components/Nav';

export const dynamic = 'force-dynamic';

const CARDS = [
  { href: '/san',   icon: '💀', title: 'سانس',    sub: 'تحدّث معه',    anim: 'icon-pulse',  color: 'cyan'   },
  { href: '/top',   icon: '🏆', title: 'التوب',    sub: 'الترتيب',      anim: 'icon-jump',   color: 'yellow' },
  { href: '/grave', icon: '⚰️', title: 'المقبرة',  sub: 'الساقطون',     anim: 'icon-wiggle', color: 'red'    },
  { href: '/me',    icon: '👤', title: 'بروفايلي', sub: 'ملفك',         anim: 'icon-glow',   color: 'blue'   },
];

const COLOR_MAP = {
  cyan:   { text: '#ffcf33' },
  yellow: { text: '#cbd5e1' },
  red:    { text: '#e74c3c' },
  blue:   { text: '#00eeff' },
};

export default async function Home() {
  const session = await getCurrentUser();
  let user = null;

  if (session) {
    await dbConnect();
    user = await User.findById(session.id)
      .select('username displayName points souls inGrave graveReason')
      .lean();
  }

  const soulColor = user
    ? (user.souls > 60 ? '#d4af37' : user.souls > 30 ? '#e67e22' : '#e74c3c')
    : '#d4af37';

  return (
    <>
      <Nav username={session?.username} />
      <main className="max-w-md mx-auto p-3 space-y-4">

        {/* ═══ العنوان ═══ */}
        <div className="panel panel-glow p-6 text-center animate-riseIn">
          <h1 className="text-4xl font-bold title-glow font-pixel mb-2">الهاوية</h1>
          <p className="text-ash text-sm">
            {session
              ? `مرحباً ${user?.displayName || session.username}`
              : 'مرحباً أيها الساقط في الهاوية'}
          </p>
        </div>

        {/* ═══ تحذير المقبرة ═══ */}
        {user?.inGrave && (
          <div className="panel border-blood p-4 text-center animate-shake border-2">
            <div className="text-blood text-3xl mb-1 animate-flicker">⚰️</div>
            <div className="text-blood font-bold font-pixel">أنت في المقبرة</div>
            <div className="text-ash text-xs mt-1">
              {user.graveReason || 'ابحث عن كلمة سرية لتعود'}
            </div>
          </div>
        )}

        {/* ═══ شبكة البطاقات ═══ */}
        <div className="grid grid-cols-2 gap-3 stagger">
          {CARDS.map((c) => {
            const isMe = c.href === '/me';
            const href = isMe && !session ? '/login' : c.href;
            const col = COLOR_MAP[c.color];
            return (
              <Link
                key={c.href}
                href={href}
                className="card"
                style={{
                  '--hover-border': col.border,
                  '--hover-shadow': col.shadow
                }}
              >
                <div className="text-center">
                  <div
                    className={`text-4xl mb-2 ${c.anim} select-none`}
                    style={{ color: col.text, filter: 'drop-shadow(0 0 8px currentColor)' }}
                  >
                    {c.icon}
                  </div>
                  <div className="font-bold font-pixel text-sm" style={{ color: col.text }}>
                    {c.title}
                  </div>
                  <div className="text-ash text-[10px] mt-1 font-pixel">
                    {isMe && !session ? 'سجّل دخول' : c.sub}
                  </div>
                </div>
              </Link>
            );
          })}
        </div>

        {/* ═══ إحصائيات ═══ */}
        {user && !user.inGrave && (
          <div className="panel p-4 animate-riseIn">
            <div className="grid grid-cols-2 gap-3 text-center">
              <div>
                <div className="text-3xl font-bold text-glow font-pixel">
                  {user.points}
                </div>
                <div className="text-ash text-xs mt-1 font-pixel">النقاط</div>
              </div>
              <div>
                <div
                  className="text-3xl font-bold font-pixel"
                  style={{ color: soulColor }}
                >
                  {user.souls}%
                </div>
                <div className="text-ash text-xs mt-1 font-pixel">الأرواح</div>
              </div>
            </div>

            {/* شريط الأرواح */}
            <div className="mt-3 w-full h-2 bg-black border border-white/30 overflow-hidden">
              <div
                className="h-full transition-all duration-700"
                style={{
                  width: `${user.souls}%`,
                  background: soulColor,
                  boxShadow: `0 0 12px ${soulColor}`
                }}
              />
            </div>
          </div>
        )}

        {/* ═══ دعوة للتسجيل ═══ */}
        {!session && (
          <div className="panel p-4 text-center animate-riseIn">
            <p className="text-ash text-xs mb-3 font-pixel">
              عضوية الهاوية بدعوة فقط
            </p>
            <Link href="/register" className="btn btn-glow w-full text-sm">
              ▸ اطلب الانضمام
            </Link>
          </div>
        )}

        <p className="text-center text-xs text-ash/40 pb-4 font-pixel">
          الهاوية · نسخة تجريبية
        </p>
      </main>
    </>
  );
          }
