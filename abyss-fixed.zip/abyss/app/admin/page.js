// app/admin/page.js
import { redirect } from 'next/navigation';
import { dbConnect } from '@/lib/mongodb';
import User from '@/lib/models/User';
import { getCurrentUser } from '@/lib/auth';
import Nav from '@/components/Nav';
import AdminPanel from '@/components/AdminPanel';

export const dynamic = 'force-dynamic';

export default async function AdminPage() {
  const session = await getCurrentUser();
  if (!session) redirect('/login');

  await dbConnect();
  const me = await User.findById(session.id).select('isAdmin username');
  if (!me?.isAdmin) redirect('/');

  return (
    <>
      <Nav username={me.username} />
      <main className="max-w-md mx-auto p-3 mt-3 animate-riseIn">
        <AdminPanel />
      </main>
    </>
  );
}
