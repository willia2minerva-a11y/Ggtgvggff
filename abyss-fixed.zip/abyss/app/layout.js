// app/layout.js
import './globals.css';
import { Cairo } from 'next/font/google';
import IntroWrapper from '@/components/IntroWrapper';

const cairo = Cairo({
  subsets: ['arabic', 'latin'],
  weight: ['400', '700', '900'],
  variable: '--font-cairo',
  display: 'swap'
});

export const metadata = {
  title: 'الهاوية',
  description: 'مرحباً أيها الساقط في الهاوية'
};

// بدون maximumScale: التكبير مسموح (إمكانية الوصول)
export const viewport = {
  width: 'device-width',
  initialScale: 1,
  viewportFit: 'cover',
  themeColor: '#0b0d10'
};

// يخفي المحتوى قبل أول رسم لمن لم يشاهد المقدمة (بدون شاشة سوداء فارغة لبقية الزوار)
const INTRO_GUARD =
  "try{if(!localStorage.getItem('hawiya_intro_seen'))document.documentElement.classList.add('intro-pending')}catch(e){}";

const PARTICLES = Array.from({ length: 16 }, (_, i) => ({
  left: `${(i * 37 + 11) % 100}%`,
  size: 3 + ((i * 5) % 5),
  duration: 16 + ((i * 7) % 14),
  delay: -((i * 3) % 16)
}));

export default function RootLayout({ children }) {
  return (
    <html lang="ar" dir="rtl" className={cairo.variable} suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: INTRO_GUARD }} />
      </head>
      <body>
        <div className="particles" aria-hidden="true">
          {PARTICLES.map((p, i) => (
            <span
              key={i}
              className="particle"
              style={{ left: p.left, width: p.size, height: p.size, animationDuration: `${p.duration}s`, animationDelay: `${p.delay}s` }}
            />
          ))}
        </div>
        <IntroWrapper>
          <div className="shell relative z-10">{children}</div>
        </IntroWrapper>
      </body>
    </html>
  );
}
