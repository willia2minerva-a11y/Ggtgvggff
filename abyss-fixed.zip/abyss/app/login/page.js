// app/login/page.js
'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Nav from '@/components/Nav';

export default function LoginPage() {
  const router = useRouter();
  const [form, setForm] = useState({ username: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    const res = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form)
    });
    const data = await res.json();
    setLoading(false);
    if (!res.ok) return setError(data.error || 'فشل الدخول');
    router.push('/me');
    router.refresh();
  };

  return (
    <>
      <Nav />
      <main className="p-4 max-w-md mx-auto mt-6">
        <div className="panel p-6 animate-riseIn">
          <h1 className="text-2xl font-bold title-glow mb-5 font-pixel">عودة إلى الهاوية</h1>

          <form onSubmit={submit} className="space-y-3">
            <input className="input" placeholder="اسم المستخدم" value={form.username}
              onChange={(e) => setForm({ ...form, username: e.target.value })} required />
            <input className="input" type="password" placeholder="كلمة السر" value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })} required />

            {error && <div className="text-blood text-sm">{error}</div>}

            <button type="submit" className="btn w-full" disabled={loading}>
              {loading ? '...' : 'ادخل'}
            </button>
          </form>

          <p className="text-center text-sm text-ash mt-4">
            جديد هنا؟ <Link href="/register" className="text-glow hover:underline">سقوط جديد</Link>
          </p>
        </div>
      </main>
    </>
  );
}
