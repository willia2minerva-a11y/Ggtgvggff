// app/top/page.js
import { dbConnect } from '@/lib/mongodb';
import User from '@/lib/models/User';
import { getCurrentUser } from '@/lib/auth';
import Nav from '@/components/Nav';

export const dynamic = 'force-dynamic';

function Rank({ list, valueKey, color, unit }) {
  if (list.length === 0) {
    return <p className="text-ash text-center py-6 text-sm">لا أحد هنا بعد…</p>;
  }
  return (
    <ol className="space-y-2">
      {list.map((u, i) => {
        const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i + 1}`;
        return (
          <li key={u._id} className="panel p-3 flex items-center justify-between">
            <div className="flex items-center gap-3 min-w-0">
              <span className="font-pixel text-glow w-6 text-center shrink-0">{medal}</span>
              <div className="min-w-0">
                <div className="truncate font-pixel">{u.displayName || u.username}</div>
                <div className="text-ash text-[10px] truncate">@{u.username}</div>
              </div>
            </div>
            <span className="font-pixel font-bold shrink-0" style={{ color }}>
              {u[valueKey]}{unit || ''}
            </span>
          </li>
        );
      })}
    </ol>
  );
}

export default async function TopPage() {
  const session = await getCurrentUser();
  await dbConnect();

  const topPoints = await User.find({ inGrave: false, isAdmin: { $ne: true } })
    .sort({ points: -1 }).limit(10).select('username displayName points').lean();
  const topSouls = await User.find({ inGrave: false, isAdmin: { $ne: true } })
    .sort({ souls: -1, points: -1 }).limit(10).select('username displayName souls').lean();

  return (
    <>
      <Nav username={session?.username} />
      <main className="max-w-md mx-auto p-3 mt-3 space-y-4 animate-riseIn">
        <div className="panel panel-glow p-6 text-center">
          <h1 className="text-3xl font-bold title-glow font-pixel">🏆 التوب</h1>
          <p className="text-ash text-xs mt-1">أعلى الساقطين شأناً</p>
        </div>

        <div className="panel p-4">
          <h2 className="text-lg font-bold text-glow mb-3 font-pixel">⚡ النقاط</h2>
          <Rank list={topPoints} valueKey="points" color="#d4af37" />
        </div>

        <div className="panel p-4">
          <h2 className="text-lg font-bold text-glow mb-3 font-pixel">❤ الأرواح</h2>
          <Rank list={topSouls} valueKey="souls" color="#00ff9d" unit="%" />
        </div>
      </main>
    </>
  );
}
