// app/me/page.js
import { redirect } from 'next/navigation';
import { dbConnect } from '@/lib/mongodb';
import User from '@/lib/models/User';
import { getCurrentUser } from '@/lib/auth';
import Nav from '@/components/Nav';

export const dynamic = 'force-dynamic';

export default async function MePage() {
  const session = await getCurrentUser();
  if (!session) redirect('/login');

  await dbConnect();
  const user = await User.findById(session.id).select('-passwordHash').lean();
  if (!user) redirect('/login');

  // ═══ حماية من القيم غير المعرّفة ═══
  const souls = typeof user.souls === 'number' ? user.souls : 100;
  const points = user.points || 0;
  const discoveredCount = Array.isArray(user.discoveredSecrets)
    ? user.discoveredSecrets.length
    : 0;
  const createdAt = user.createdAt || new Date();
  const lastSeen = user.lastSeen || createdAt;

  const soulPct = Math.max(0, Math.min(100, souls));
  const soulColor =
    soulPct > 60 ? '#d4af37' : soulPct > 30 ? '#e67e22' : '#e74c3c';

  const displayName = user.displayName || user.username;
  const initial = displayName.trim()[0] || '?';

  return (
    <>
      <Nav username={user.username} />
      <main className="max-w-md mx-auto p-3 mt-3 space-y-4">

        {/* ═══ بطاقة الساقط ═══ */}
        <div className="panel panel-glow p-6 text-center animate-riseIn">
          <div className="relative w-32 h-32 mx-auto mb-4">
            <div
              className="absolute inset-0 rounded-full animate-bluePulse"
              style={{
                border: '3px solid #fff',
                background: '#000',
                boxShadow: `0 0 25px ${soulColor}, inset 0 0 15px ${soulColor}40`,
              }}
            />
            <div className="absolute inset-0 flex items-center justify-center text-5xl font-bold font-pixel z-10">
              {initial}
            </div>
          </div>

          <div className="text-2xl font-bold font-pixel">{displayName}</div>
          <div className="text-glow text-sm font-pixel mt-1">
            @{user.username}
          </div>

          <div className="mt-3 inline-block px-3 py-1 border border-glow/50 text-glow text-xs font-pixel">
            {user.title || 'ساقط جديد'}
          </div>

          {user.inGrave && (
            <div className="mt-4 panel border-blood p-3 text-blood text-sm font-pixel animate-flicker border-2">
              ⚰️ أنت في المقبرة
              {user.graveReason && (
                <div className="text-xs mt-1 text-ash">
                  السبب: {user.graveReason}
                </div>
              )}
            </div>
          )}
        </div>

        {/* ═══ شريط الأرواح ═══ */}
        <div className="panel p-5 animate-riseIn">
          <div className="flex justify-between text-sm mb-2 font-pixel">
            <span>❤ الأرواح</span>
            <span style={{ color: soulColor }}>{soulPct}%</span>
          </div>
          <div className="w-full h-3 bg-black border border-white/40 overflow-hidden">
            <div
              className="h-full transition-all duration-700"
              style={{
                width: `${soulPct}%`,
                background: soulColor,
                boxShadow: `0 0 12px ${soulColor}`,
              }}
            />
          </div>
          <div className="text-[10px] text-ash mt-2 font-pixel text-center">
            {soulPct > 60 && 'متماسك… لكن لا تفرح'}
            {soulPct > 30 && soulPct <= 60 && 'على وشك السقوط… احترس'}
            {soulPct <= 30 && 'أنت قريب من المقبرة…'}
          </div>
        </div>

        {/* ═══ الأرقام ═══ */}
        <div className="grid grid-cols-2 gap-3 stagger">
          <div className="panel p-4 text-center">
            <div className="text-3xl font-bold text-glow font-pixel">
              {points}
            </div>
            <div className="text-ash text-xs mt-1 font-pixel">النقاط</div>
          </div>
          <div className="panel p-4 text-center">
            <div
              className="text-3xl font-bold font-pixel"
              style={{ color: soulColor }}
            >
              {souls}
            </div>
            <div className="text-ash text-xs mt-1 font-pixel">أرواح</div>
          </div>
        </div>

        {/* ═══ السجل ═══ */}
        <div className="panel p-4 animate-riseIn">
          <div className="text-sm font-bold mb-3 font-pixel text-glow flex items-center gap-2">
            <span className="icon-pulse">📜</span> السجل
          </div>
          <div className="space-y-2 text-xs font-pixel">
            <div className="flex justify-between">
              <span className="text-ash">انضم في</span>
              <span>{new Date(createdAt).toLocaleDateString('ar-EG')}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-ash">آخر زيارة</span>
              <span>{new Date(lastSeen).toLocaleDateString('ar-EG')}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-ash">كلمات سرية</span>
              <span className="text-glow">{discoveredCount}</span>
            </div>
            {user.violations > 0 && (
              <div className="flex justify-between">
                <span className="text-ash">مخالفات</span>
                <span className="text-blood">{user.violations}</span>
              </div>
            )}
          </div>
        </div>

        <p className="text-center text-xs text-ash/40 pb-4 font-pixel">
          الهاوية · نسخة تجريبية
        </p>
      </main>
    </>
  );
          }
