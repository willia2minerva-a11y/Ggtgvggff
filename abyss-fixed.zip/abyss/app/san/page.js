// app/san/page.js
import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import Nav from '@/components/Nav';
import SanChat from '@/components/SanChat';

export default async function SanPage() {
  const session = await getCurrentUser();
  if (!session) redirect('/login');

  return (
    <>
      <Nav username={session.username} />
      <main className="max-w-md mx-auto p-3 mt-3 animate-riseIn">
        <SanChat />
      </main>
    </>
  );
}
