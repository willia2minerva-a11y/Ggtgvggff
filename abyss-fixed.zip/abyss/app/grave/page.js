// app/grave/page.js
import { dbConnect } from '@/lib/mongodb';
import User from '@/lib/models/User';
import { getCurrentUser } from '@/lib/auth';
import Nav from '@/components/Nav';

export const dynamic = 'force-dynamic';

export default async function GravePage() {
  const session = await getCurrentUser();
  await dbConnect();

  const fallen = await User.find({ inGrave: true })
    .sort({ lastSeen: -1 }).limit(50)
    .select('username displayName graveReason lastSeen').lean();

  return (
    <>
      <Nav username={session?.username} />
      <main className="max-w-md mx-auto p-3 mt-3 space-y-4 animate-riseIn">
        <div className="panel panel-glow p-6 text-center border-blood/60">
          <h1 className="text-3xl font-bold font-pixel mb-1 text-blood animate-flicker">
            ⚰️ المقبرة
          </h1>
          <p className="text-ash text-xs">مقبرة الساقطين</p>
        </div>

        {fallen.length === 0 ? (
          <div className="panel p-10 text-center">
            <div className="text-5xl mb-3 animate-bob">🕯️</div>
            <p className="text-glow font-pixel mb-2">المقبرة فارغة…</p>
            <p className="text-ash text-sm">لا أحد سقط بعد.</p>
            <p className="text-ash/60 text-xs mt-3">ابقَ على قيد الحياة.</p>
          </div>
        ) : (
          <ul className="space-y-2">
            {fallen.map((u) => (
              <li key={u._id} className="panel p-4 border-blood/40">
                <div className="flex items-center justify-between">
                  <div className="min-w-0">
                    <div className="font-pixel truncate">{u.displayName || u.username}</div>
                    <div className="text-ash text-[10px] truncate">@{u.username}</div>
                  </div>
                  <div className="text-blood text-xs shrink-0 font-pixel">
                    {u.graveReason || 'سقط'}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </main>
    </>
  );
}
