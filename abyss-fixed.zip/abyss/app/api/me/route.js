// app/api/me/route.js
import { NextResponse } from 'next/server';
import { dbConnect } from '@/lib/mongodb';
import User from '@/lib/models/User';
import { getCurrentUser } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const session = await getCurrentUser();
    if (!session) return NextResponse.json({ error: 'غير مسجل' }, { status: 401 });

    await dbConnect();
    const user = await User.findById(session.id).select('-passwordHash').lean();
    if (!user) return NextResponse.json({ error: 'غير موجود' }, { status: 404 });

    // ═══ ضمان وجود كل الحقول (إصلاح الوثائق القديمة) ═══
    return NextResponse.json({
      user: {
        _id: user._id,
        username: user.username,
        displayName: user.displayName || user.username,
        title: user.title || 'ساقط جديد',
        avatar: user.avatar || '',
        points: user.points || 0,
        souls: typeof user.souls === 'number' ? user.souls : 100,
        inGrave: !!user.inGrave,
        graveReason: user.graveReason || '',
        graveSince: user.graveSince || null,
        isAdmin: !!user.isAdmin,
        discoveredSecrets: user.discoveredSecrets || [],
        violations: user.violations || 0,
        lastSeen: user.lastSeen || user.createdAt,
        lastDailyBonus: user.lastDailyBonus || null,
        createdAt: user.createdAt || new Date()
      }
    });
  } catch (e) {
    console.error('me error', e);
    return NextResponse.json({ error: 'خطأ في الخادم' }, { status: 500 });
  }
}
