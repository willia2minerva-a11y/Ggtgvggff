// app/api/admin/secrets/route.js
import { NextResponse } from 'next/server';
import mongoose from 'mongoose';
import { z } from 'zod';
import { dbConnect } from '@/lib/mongodb';
import Secret from '@/lib/models/Secret';
import Log from '@/lib/models/Log';
import { requireAdmin } from '@/lib/admin';
import { fail, readJson } from '@/lib/http';

const MOODS = ['normal', 'laugh', 'angry', 'sad', 'surprise', 'sleep', 'scary', 'secret'];
const schema = z.object({
  word: z.string().trim().min(1, 'الكلمة مطلوبة').max(40),
  reply: z.string().trim().min(1, 'الرد مطلوب').max(500),
  mood: z.enum(MOODS).optional().default('secret'),
  rewardPoints: z.coerce.number().int().min(0).max(100_000).optional().default(0),
  rewardSouls: z.coerce.number().int().min(0).max(100).optional().default(0),
  maxUses: z.coerce.number().int().min(0).max(1_000_000).optional().default(0),
  aliases: z.union([z.string(), z.array(z.string())]).optional().default('')
});

export async function GET() {
  try {
    if (!(await requireAdmin())) return fail('ممنوع', 403);
    const list = await Secret.find().sort({ createdAt: -1 }).limit(500).lean();
    return NextResponse.json({ list });
  } catch (e) {
    console.error('admin secrets GET', e);
    return fail('خطأ في الخادم', 500);
  }
}

export async function POST(req) {
  try {
    const admin = await requireAdmin();
    if (!admin) return fail('ممنوع', 403);

    const parsed = schema.safeParse(await readJson(req));
    if (!parsed.success) return fail(parsed.error.errors[0].message);
    const d = parsed.data;
    const raw = Array.isArray(d.aliases) ? d.aliases : d.aliases.split(',');
    const aliases = [...new Set(raw.map((s) => s.trim().toLowerCase()).filter(Boolean))].slice(0, 20);

    try {
      const secret = await Secret.create({
        word: d.word.toLowerCase(), aliases, reply: d.reply, mood: d.mood,
        rewardPoints: d.rewardPoints, rewardSouls: d.rewardSouls, maxUses: d.maxUses, active: true
      });
      await Log.create({ type: 'admin_action', actor: admin.id, message: `إضافة كلمة: ${secret.word}` });
      return NextResponse.json({ ok: true, secret });
    } catch (e) {
      if (e.code === 11000) return fail('الكلمة موجودة', 409);
      throw e;
    }
  } catch (e) {
    console.error('admin secrets POST', e);
    return fail('خطأ في الخادم', 500);
  }
}

export async function DELETE(req) {
  try {
    const admin = await requireAdmin();
    if (!admin) return fail('ممنوع', 403);
    const body = await readJson(req);
    if (!mongoose.isValidObjectId(body?.id)) return fail('معرّف غير صالح');
    const del = await Secret.findByIdAndDelete(body.id);
    if (!del) return fail('غير موجود', 404);
    await Log.create({ type: 'admin_action', actor: admin.id, message: `حذف كلمة: ${del.word}` });
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error('admin secrets DELETE', e);
    return fail('خطأ في الخادم', 500);
  }
}
