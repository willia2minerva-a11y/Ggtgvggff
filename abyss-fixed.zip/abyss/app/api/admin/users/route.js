// app/api/admin/users/route.js
import { NextResponse } from 'next/server';
import mongoose from 'mongoose';
import { z } from 'zod';
import { dbConnect } from '@/lib/mongodb';
import User from '@/lib/models/User';
import Log from '@/lib/models/Log';
import { requireAdmin } from '@/lib/admin';
import { fail, readJson } from '@/lib/http';

const schema = z.object({
  id: z.string().refine((v) => mongoose.isValidObjectId(v), 'معرّف غير صالح'),
  action: z.enum(['addPoints', 'setPoints', 'addSouls', 'setSouls', 'grave', 'revive']),
  value: z.coerce.number().finite().min(-1_000_000).max(1_000_000).optional().default(0),
  reason: z.string().max(100).optional().default('')
});
const clamp = (n) => Math.max(0, Math.min(100, Math.round(n)));

export async function GET() {
  try {
    if (!(await requireAdmin())) return fail('ممنوع', 403);
    const users = await User.find().sort({ points: -1 }).limit(500).select('-passwordHash').lean();
    return NextResponse.json({ users });
  } catch (e) {
    console.error('admin users GET', e);
    return fail('خطأ في الخادم', 500);
  }
}

export async function POST(req) {
  try {
    const admin = await requireAdmin();
    if (!admin) return fail('ممنوع', 403);

    const parsed = schema.safeParse(await readJson(req));
    if (!parsed.success) return fail(parsed.error.errors[0].message);
    const { id, action, value, reason } = parsed.data;

    const target = await User.findById(id);
    if (!target) return fail('غير موجود', 404);
    if (action === 'grave' && (target.isAdmin || target._id.toString() === admin.id)) {
      return fail('لا يمكن دفن الإدارة', 400);
    }

    if (action === 'addPoints') target.points = Math.max(0, target.points + Math.round(value));
    else if (action === 'setPoints') target.points = Math.max(0, Math.round(value));
    else if (action === 'addSouls') target.souls = clamp(target.souls + value);
    else if (action === 'setSouls') target.souls = clamp(value);
    else if (action === 'grave') {
      target.inGrave = true; target.souls = 0;
      target.graveReason = reason || 'قرار إداري'; target.graveSince = new Date();
    } else if (action === 'revive') {
      target.inGrave = false; target.souls = 50; target.graveReason = ''; target.graveSince = null;
    }
    await target.save();

    await Log.create({
      type: 'admin_action', actor: admin.id, target: target._id,
      message: `${action} على ${target.username}`, meta: { value, reason }
    });

    const obj = target.toObject();
    delete obj.passwordHash;
    return NextResponse.json({ ok: true, user: obj });
  } catch (e) {
    console.error('admin users POST', e);
    return fail('خطأ في الخادم', 500);
  }
}
