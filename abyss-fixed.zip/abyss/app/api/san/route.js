// app/api/san/route.js
import { NextResponse } from 'next/server';
import { dbConnect } from '@/lib/mongodb';
import User from '@/lib/models/User';
import Secret from '@/lib/models/Secret';
import Log from '@/lib/models/Log';
import { getCurrentUser } from '@/lib/auth';
import { pickReply, detectMood, classifyIntent } from '@/lib/replies';
import { rateLimit } from '@/lib/rateLimit';
import { fail, readJson } from '@/lib/http';

const CHAT_POINT_COOLDOWN_MS = 30_000; // نقطة تفاعل واحدة كل 30 ثانية
const ANGRY_SOUL_PENALTY = 3;

const out = (body) => NextResponse.json(body);
const pub = (u) => ({ points: u.points, souls: u.souls });
const secretFilter = (clean) => ({
  active: true,
  $and: [
    { $or: [{ word: clean }, { aliases: clean }] }
  ]
});

export async function POST(req) {
  try {
    const session = await getCurrentUser();
    if (!session) return fail('سجّل دخولك أولاً', 401);

    const rl = await rateLimit(`san:${session.id}`, 20, 60);
    if (!rl.ok) return fail('مهلاً… تكلّم ببطء.', 429, { 'Retry-After': String(rl.retryAfter) });

    const body = await readJson(req);
    const message = body?.message;
    if (typeof message !== 'string' || !message.trim() || message.length > 500) {
      return fail('رسالة غير صالحة');
    }

    await dbConnect();
    const user = await User.findById(session.id).select('points souls inGrave');
    if (!user) return fail('غير موجود', 404);

    if (user.inGrave) {
      return out({ reply: 'أنت في المقبرة… لا تتحدث معي حتى تعود.', mood: 'scary', user: pub(user) });
    }

    const uid = user._id;
    const clean = message.trim().toLowerCase();

    // ═══ الطبقة 1: كلمة سرية — مطالبة ذرية (لا يمكن استغلالها بطلبات متوازية) ═══
    const claimed = await Secret.findOneAndUpdate(
      {
        active: true,
        usedBy: { $ne: uid },
        $and: [
          { $or: [{ word: clean }, { aliases: clean }] },
          { $or: [{ maxUses: { $not: { $gt: 0 } } }, { $expr: { $lt: [{ $size: '$usedBy' }, '$maxUses'] } }] }
        ]
      },
      { $addToSet: { usedBy: uid } },
      { new: true }
    );

    if (claimed) {
      const rp = Math.max(0, claimed.rewardPoints || 0);
      const rs = Math.max(0, claimed.rewardSouls || 0);
      let updated;
      try {
        updated = await User.findByIdAndUpdate(
          uid,
          [{ $set: {
            points: { $add: [{ $ifNull: ['$points', 0] }, rp] },
            souls: { $min: [100, { $add: [{ $ifNull: ['$souls', 100] }, rs] }] },
            discoveredSecrets: { $setUnion: [{ $ifNull: ['$discoveredSecrets', []] }, [claimed._id]] }
          } }],
          { new: true, updatePipeline: true }
        ).select('points souls');
      } catch (e) {
        await Secret.updateOne({ _id: claimed._id }, { $pull: { usedBy: uid } }); // تراجع
        throw e;
      }
      await Log.create({ type: 'secret_found', actor: uid, message: `كشف الكلمة: ${claimed.word}` });
      return out({
        reply: claimed.reply, mood: claimed.mood || 'secret', type: 'secret',
        reward: { points: rp, souls: rs }, user: pub(updated)
      });
    }

    // لم تُمنح: اشرح السبب إن كانت الكلمة موجودة أصلاً
    const known = await Secret.findOne(secretFilter(clean)).select('usedBy');
    if (known) {
      const already = known.usedBy.some((id) => id.equals(uid));
      return out({
        reply: already ? 'استخدمت هذه الكلمة من قبل… مرة واحدة تكفي.' : 'هذه الكلمة انتهت صلاحيتها… ابحث عن غيرها.',
        mood: 'normal', type: 'secret', user: pub(user)
      });
    }

    // ═══ الطبقة 2 + 3: مشاعر + رد عادي ═══
    let mood = detectMood(message);
    const intent = classifyIntent(message);
    let reply = intent === 'greet' && mood === 'normal' ? 'مرحباً… اجلس. عندك ما تقوله؟' : pickReply(mood);
    let stats = pub(user);

    if (mood === 'angry') {
      // الإساءة تُنقص الأرواح فعلاً، والوصول للصفر يعني المقبرة
      const u = await User.findByIdAndUpdate(
        uid,
        [{ $set: {
          souls: { $max: [0, { $subtract: [{ $ifNull: ['$souls', 100] }, ANGRY_SOUL_PENALTY] }] },
          violations: { $add: [{ $ifNull: ['$violations', 0] }, 1] }
        } }],
        { new: true, updatePipeline: true }
      ).select('points souls');
      stats = pub(u);
      if (u.souls <= 0) {
        await User.updateOne(
          { _id: uid, inGrave: false },
          { $set: { inGrave: true, graveReason: 'نفدت أرواحه', graveSince: new Date() } }
        );
        await Log.create({ type: 'auto_grave', actor: uid, message: 'نفدت الأرواح' });
        reply = '…سقطت. المقبرة تنتظرك.';
        mood = 'scary';
      }
    } else if (message.trim().length > 5) {
      // نقطة تفاعل واحدة كل 30 ثانية، بتحديث ذري مشروط
      const u = await User.findOneAndUpdate(
        { _id: uid, $or: [{ lastChatPoint: null }, { lastChatPoint: { $lt: new Date(Date.now() - CHAT_POINT_COOLDOWN_MS) } }] },
        { $inc: { points: 1 }, $set: { lastChatPoint: new Date() } },
        { new: true }
      ).select('points souls');
      if (u) stats = pub(u);
    }

    return out({ reply, mood, user: stats });
  } catch (e) {
    console.error('san error', e);
    return fail('خطأ في الخادم', 500);
  }
}
