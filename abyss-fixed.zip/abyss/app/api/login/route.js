// app/api/login/route.js
import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { dbConnect } from '@/lib/mongodb';
import User from '@/lib/models/User';
import { ensureAdmin } from '@/lib/init';
import { signToken, setSessionCookie } from '@/lib/auth';
import { rateLimit, clientIp } from '@/lib/rateLimit';
import { fail, readJson } from '@/lib/http';

const schema = z.object({ username: z.string().min(1).max(20), password: z.string().min(1).max(100) });
// يوازن زمن الاستجابة سواء وُجد المستخدم أم لا
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', 12);

export async function POST(req) {
  try {
    const parsed = schema.safeParse(await readJson(req));
    if (!parsed.success) return fail('أدخل الاسم وكلمة السر');
    const username = parsed.data.username.trim().toLowerCase();

    const ip = await rateLimit(`login:ip:${clientIp(req)}`, 30, 600);
    const acc = await rateLimit(`login:u:${username}`, 8, 600);
    if (!ip.ok || !acc.ok) {
      const wait = Math.max(ip.retryAfter, acc.retryAfter);
      return fail('محاولات كثيرة… انتظر قليلاً', 429, { 'Retry-After': String(wait) });
    }

    await ensureAdmin();
    const user = await User.findOne({ username }).select('username passwordHash');
    const ok = await bcrypt.compare(parsed.data.password, user?.passwordHash || DUMMY_HASH);
    if (!user || !ok) return fail('بيانات خاطئة', 401);

    await User.updateOne({ _id: user._id }, { $set: { lastSeen: new Date() } });

    const token = await signToken({ id: user._id.toString(), username: user.username });
    const res = NextResponse.json({ ok: true, username: user.username });
    setSessionCookie(res, token);
    return res;
  } catch (e) {
    console.error('login error', e);
    return fail('خطأ في الخادم', 500);
  }
}
