// app/api/register/route.js
import { NextResponse } from 'next/server';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { dbConnect } from '@/lib/mongodb';
import User from '@/lib/models/User';
import { ensureAdmin } from '@/lib/init';
import { signToken, setSessionCookie } from '@/lib/auth';
import { rateLimit, clientIp } from '@/lib/rateLimit';
import { fail, readJson } from '@/lib/http';

const schema = z.object({
  username: z.string().trim().min(3).max(20).regex(/^[a-zA-Z0-9_]+$/, 'حروف إنجليزية وأرقام و _ فقط'),
  password: z.string().min(8, 'كلمة السر 8 أحرف على الأقل').max(50),
  displayName: z.string().trim().min(1).max(30).optional().or(z.literal('')),
  inviteCode: z.string().min(1).max(100)
});

const sha = (v) => crypto.createHash('sha256').update(v).digest();
const sameSecret = (a, b) => crypto.timingSafeEqual(sha(a), sha(b));

export async function POST(req) {
  try {
    const rl = await rateLimit(`register:${clientIp(req)}`, 10, 3600);
    if (!rl.ok) return fail('محاولات كثيرة… حاول لاحقاً', 429, { 'Retry-After': String(rl.retryAfter) });

    const parsed = schema.safeParse(await readJson(req));
    if (!parsed.success) return fail(parsed.error.errors[0].message);
    const { username, password, displayName, inviteCode } = parsed.data;

    const expected = process.env.INVITE_CODE;
    if (!expected) return fail('التسجيل مغلق حالياً', 503);
    if (!sameSecret(inviteCode, expected)) return fail('كود الدعوة غير صحيح', 403);

    await ensureAdmin();
    const uname = username.toLowerCase();
    if (await User.exists({ username: uname })) return fail('الاسم مستخدم مسبقاً', 409);

    const passwordHash = await bcrypt.hash(password, 12);
    let user;
    try {
      user = await User.create({
        username: uname, passwordHash,
        displayName: displayName || username,
        title: 'ساقط جديد', souls: 100, points: 0
      });
    } catch (e) {
      if (e.code === 11000) return fail('الاسم مستخدم مسبقاً', 409); // سباق تسجيل متزامن
      throw e;
    }

    const token = await signToken({ id: user._id.toString(), username: user.username });
    const res = NextResponse.json({ ok: true, username: user.username });
    setSessionCookie(res, token);
    return res;
  } catch (e) {
    console.error('register error', e);
    return fail('خطأ في الخادم', 500);
  }
}
