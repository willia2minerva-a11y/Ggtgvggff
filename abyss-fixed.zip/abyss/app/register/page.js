// app/register/page.js
'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Nav from '@/components/Nav';

export default function RegisterPage() {
  const router = useRouter();
  const [form, setForm] = useState({ username: '', password: '', displayName: '', inviteCode: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    const res = await fetch('/api/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form)
    });
    const data = await res.json();
    setLoading(false);
    if (!res.ok) return setError(data.error || 'فشل التسجيل');
    router.push('/me');
    router.refresh();
  };

  return (
    <>
      <Nav />
      <main className="p-4 max-w-md mx-auto mt-6">
        <div className="panel p-6 animate-riseIn">
          <h1 className="text-2xl font-bold title-glow mb-1 font-pixel">تسجيل السقوط</h1>
          <p className="text-ash text-sm mb-5">مرحباً أيها الساقط في الهاوية</p>

          <form onSubmit={submit} className="space-y-3">
            <input className="input" placeholder="اسم المستخدم (بالإنجليزية)" value={form.username}
              onChange={(e) => setForm({ ...form, username: e.target.value })} required />
            <input className="input" placeholder="الاسم المعروض (اختياري)" value={form.displayName}
              onChange={(e) => setForm({ ...form, displayName: e.target.value })} />
            <input className="input" type="password" placeholder="كلمة السر" value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })} required />
            <input className="input" placeholder="كود الدعوة" value={form.inviteCode}
              onChange={(e) => setForm({ ...form, inviteCode: e.target.value })} required />

            {error && <div className="text-blood text-sm">{error}</div>}

            <button type="submit" className="btn w-full" disabled={loading}>
              {loading ? '...' : 'اسقط'}
            </button>
          </form>

          <p className="text-center text-sm text-ash mt-4">
            لديك حساب؟ <Link href="/login" className="text-glow hover:underline">سجّل دخولك</Link>
          </p>
        </div>
      </main>
    </>
  );
}
