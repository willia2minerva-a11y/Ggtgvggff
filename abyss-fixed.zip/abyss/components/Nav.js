// components/Nav.js — شريط علوي + قائمة جانبية منزلقة (على طريقة برج الصيد)
'use client';
import Link from 'next/link';
import { useRouter, usePathname } from 'next/navigation';
import { useCallback, useEffect, useState } from 'react';
import { soulColor } from '@/lib/ui';

const MENU_ITEMS = [
  { href: '/', icon: '🏠', label: 'الرئيسية' },
  { href: '/san', icon: '💀', label: 'سانس' },
  { href: '/top', icon: '🏆', label: 'التوب' },
  { href: '/grave', icon: '⚰️', label: 'المقبرة' },
  { href: '/me', icon: '👤', label: 'بروفايلي' }
];

export default function Nav({ username }) {
  const router = useRouter();
  const pathname = usePathname();
  const [stats, setStats] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [open, setOpen] = useState(false);

  // يجلب الإحصاءات مرة واحدة، ثم يتحدث عبر حدث 'abyss:stats' من الدردشة
  const load = useCallback(() => {
    if (!username) return;
    fetch('/api/me', { cache: 'no-store' })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (d?.user) { setStats({ points: d.user.points, souls: d.user.souls }); setIsAdmin(!!d.user.isAdmin); }
      })
      .catch(() => {});
  }, [username]);

  useEffect(() => {
    load();
    const onStats = (e) => e.detail && setStats((s) => ({ ...(s || {}), ...e.detail }));
    window.addEventListener('abyss:stats', onStats);
    return () => window.removeEventListener('abyss:stats', onStats);
  }, [load]);

  useEffect(() => { setOpen(false); }, [pathname]);
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => e.key === 'Escape' && setOpen(false);
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  const logout = async () => {
    await fetch('/api/logout', { method: 'POST' });
    router.push('/');
    router.refresh();
  };

  const color = stats ? soulColor(stats.souls) : '#d4af37';
  const items = isAdmin ? [...MENU_ITEMS, { href: '/admin', icon: '⚙️', label: 'الإدارة' }] : MENU_ITEMS;

  return (
    <>
      <header className="topbar">
        <div className="max-w-md mx-auto px-3 h-14 flex items-center justify-between gap-2">
          <Link href="/" className="flex items-center gap-2 shrink-0">
            <span className="text-xl animate-flicker">💀</span>
            <span className="text-xl font-black title-glow">الهاوية</span>
          </Link>

          {username ? (
            <div className="flex items-center gap-3">
              {stats && (
                <div className="hidden xs:flex items-center gap-3 text-xs font-bold">
                  <span className="text-glow">⚡ {stats.points}</span>
                  <span style={{ color }}>❤ {stats.souls}%</span>
                </div>
              )}
              <button onClick={() => setOpen(true)} className="btn !py-1 !px-3 text-xl leading-none"
                aria-label="القائمة" aria-expanded={open}>☰</button>
            </div>
          ) : (
            <div className="flex gap-2">
              <Link href="/login" className="btn !text-xs !py-1 !px-3">دخول</Link>
              <Link href="/register" className="btn btn-glow !text-xs !py-1 !px-3">تسجيل</Link>
            </div>
          )}
        </div>
      </header>

      <div className={`overlay ${open ? 'active' : ''}`} onClick={() => setOpen(false)} aria-hidden="true" />
      <aside className={`sidebar ${open ? 'active' : ''}`} inert={open ? undefined : ''} aria-label="القائمة">
        <div className="p-5 text-center border-b border-white/10">
          <div className="text-4xl mb-1 animate-flicker">💀</div>
          <div className="font-black title-glow text-lg">{username ? `@${username}` : 'الهاوية'}</div>
          {stats && (
            <div className="mt-2 flex justify-center gap-4 text-xs font-bold">
              <span className="text-glow">⚡ {stats.points}</span>
              <span style={{ color }}>❤ {stats.souls}%</span>
            </div>
          )}
        </div>
        <nav className="py-2">
          {items.map((item) => {
            const active = pathname === item.href;
            return (
              <Link key={item.href} href={item.href}
                className={`flex items-center gap-3 px-5 py-3 font-bold border-b border-white/5 transition-colors hover:text-glow hover:bg-white/5 ${active ? 'text-glow bg-white/5' : ''}`}>
                <span className="text-xl">{item.icon}</span>
                <span>{item.label}</span>
              </Link>
            );
          })}
          <button onClick={logout}
            className="w-full flex items-center gap-3 px-5 py-3 font-bold text-blood hover:bg-blood/10 transition-colors text-start">
            <span className="text-xl">🚪</span>
            <span>خروج</span>
          </button>
        </nav>
        <button onClick={() => setOpen(false)} className="btn w-[calc(100%-2rem)] mx-4 my-3">✕ إغلاق</button>
      </aside>
    </>
  );
}
