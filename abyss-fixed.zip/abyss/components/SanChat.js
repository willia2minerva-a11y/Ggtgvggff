// components/SanChat.js
'use client';
import { useState, useRef, useEffect, useCallback } from 'react';
import { soulColor } from '@/lib/ui';

const MOOD_IMG = {
  normal: '/san/normal.png', laugh: '/san/laugh.png', angry: '/san/angry.png',
  sad: '/san/sad.png', surprise: '/san/surprise.png', sleep: '/san/sleep.png',
  scary: '/san/scary.png', secret: '/san/secret.png'
};
const GLOW = {
  scary: 'bg-blue-500', angry: 'bg-red-500', laugh: 'bg-yellow-400',
  sad: 'bg-blue-900', secret: 'bg-yellow-500', normal: 'bg-amber-500'
};
const TYPE_SPEED = 30;

export default function SanChat() {
  const [displayText, setDisplayText] = useState('');
  const [reply, setReply] = useState({ text: 'مرحباً أيها الساقط في الهاوية…', n: 0 });
  const [mood, setMood] = useState('normal');
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [shake, setShake] = useState(false);
  const [jump, setJump] = useState(false);
  const [tilt, setTilt] = useState(0);
  const [flash, setFlash] = useState(false);
  const [stats, setStats] = useState({ points: 0, souls: 100 });
  const [reward, setReward] = useState(null);
  const [sound, setSound] = useState(false);
  const typingRef = useRef(null);
  const audioRef = useRef(null);
  const soundRef = useRef(false);
  const timers = useRef([]);

  const later = (fn, ms) => timers.current.push(setTimeout(fn, ms));
  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  const publishStats = (s) => {
    setStats(s);
    window.dispatchEvent(new CustomEvent('abyss:stats', { detail: s }));
  };

  // AudioContext يُنشأ عند ضغطة المستخدم (وإلا يبقى suspended على الموبايل)
  const toggleSound = () => {
    const next = !soundRef.current;
    soundRef.current = next;
    setSound(next);
    if (next) {
      try {
        if (!audioRef.current) audioRef.current = new (window.AudioContext || window.webkitAudioContext)();
        audioRef.current.resume?.();
      } catch {}
    }
  };

  const playTick = useCallback(() => {
    if (!soundRef.current || !audioRef.current) return;
    try {
      const ctx = audioRef.current;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.frequency.value = 800 + Math.random() * 200;
      osc.type = 'square';
      gain.gain.setValueAtTime(0.02, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.05);
      osc.connect(gain); gain.connect(ctx.destination);
      osc.start(); osc.stop(ctx.currentTime + 0.05);
    } catch {}
  }, []);

  // الاعتماد على reply.n يعيد الكتابة حتى لو تكرر نفس الرد حرفياً
  useEffect(() => {
    if (typingRef.current) clearInterval(typingRef.current);
    setDisplayText('');
    let i = 0;
    typingRef.current = setInterval(() => {
      i++;
      setDisplayText(reply.text.slice(0, i));
      if (i % 2 === 0) playTick();
      if (i >= reply.text.length) { clearInterval(typingRef.current); typingRef.current = null; }
    }, TYPE_SPEED);
    return () => { if (typingRef.current) clearInterval(typingRef.current); };
  }, [reply, playTick]);

  useEffect(() => {
    fetch('/api/me', { cache: 'no-store' }).then((r) => r.json()).then((d) => {
      if (d.user) setStats({ points: d.user.points, souls: d.user.souls });
    }).catch(() => {});
  }, []);

  const say = (text, m = 'normal') => { setReply((r) => ({ text, n: r.n + 1 })); setMood(m); };

  const send = async () => {
    const text = input.trim();
    if (!text || loading) return;
    setInput(''); setLoading(true); setReward(null);
    try {
      const res = await fetch('/api/san', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text })
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        say(data.error || '...');
      } else {
        say(data.reply, data.mood || 'normal');
        if (data.user) publishStats(data.user);
        if (data.reward) { setReward(data.reward); setFlash(true); later(() => setFlash(false), 800); }
        if (data.mood === 'scary' || data.mood === 'angry') { setShake(true); later(() => setShake(false), 600); }
        if (data.mood === 'surprise' || data.mood === 'laugh') { setJump(true); later(() => setJump(false), 400); }
        if (data.mood === 'sad') { setTilt(-3); later(() => setTilt(0), 1500); }
        if (data.mood === 'sleep') { setTilt(5); later(() => setTilt(0), 2000); }
      }
    } catch {
      say('...انقطع الاتصال.');
    }
    setLoading(false);
  };

  const skipTyping = () => {
    if (typingRef.current) {
      clearInterval(typingRef.current); typingRef.current = null;
      setDisplayText(reply.text);
    }
  };

  const typing = displayText.length < reply.text.length;

  return (
    <div className={`space-y-3 ${shake ? 'animate-shake' : ''}`}>
      <div className="panel !p-2 flex items-center justify-between text-sm font-bold">
        <span className="text-glow">⚡ {stats.points}</span>
        <button onClick={toggleSound} className="text-ash hover:text-glow px-2" aria-label={sound ? 'كتم الصوت' : 'تشغيل الصوت'}>
          {sound ? '🔊' : '🔇'}
        </button>
        <span style={{ color: soulColor(stats.souls) }}>❤ {stats.souls}%</span>
      </div>

      <div className="text-center">
        <div className="relative inline-block transition-transform duration-300"
          style={{ transform: `translateY(${jump ? -8 : 0}px) rotate(${tilt}deg) scale(${jump ? 1.1 : 1})` }}>
          <div className={`absolute inset-0 rounded-full blur-2xl opacity-40 transition-all duration-500 ${GLOW[mood] || GLOW.normal}`} />
          <img src={MOOD_IMG[mood] || MOOD_IMG.normal} alt="سانس"
            className={`w-44 h-44 relative pixelated animate-bob select-none transition-opacity duration-300 ${loading ? 'opacity-70 blur-[1px]' : ''}`}
            draggable={false}
            onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = MOOD_IMG.normal; }} />
        </div>
      </div>

      <div className={`san-bubble transition-shadow ${flash ? 'ring-2 ring-yellow-400' : ''}`}
        aria-live="polite" onClick={typing ? skipTyping : undefined}>
        <span className={typing ? 'cursor' : ''}>{displayText}</span>
        {!typing && !loading && <span className="inline-block ms-2 text-glow animate-blink text-xs">▼</span>}
      </div>

      {reward && (
        <div className="panel panel-glow !border-yellow-400/60 p-3 text-center text-sm animate-riseIn">
          <div className="text-yellow-400 font-bold animate-flicker">✨ كشفت شيئاً</div>
          <div className="text-xs text-ash mt-1">
            {reward.points > 0 && <span className="me-2">+{reward.points} نقطة</span>}
            {reward.souls > 0 && <span className="text-green-400 me-2">+{reward.souls} أرواح</span>}
          </div>
        </div>
      )}

      <div className="flex gap-2 items-stretch">
        <input className="input flex-1" placeholder="اكتب رسالتك…" value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && !e.nativeEvent.isComposing && send()}
          maxLength={500} disabled={loading} />
        <button className="btn px-5" onClick={send} disabled={loading || !input.trim()} aria-label="إرسال">
          {loading ? '…' : '▸'}
        </button>
      </div>

      <p className="text-center text-xs text-ash/70">بعض الكلمات… تخفي أسراراً</p>
    </div>
  );
}
