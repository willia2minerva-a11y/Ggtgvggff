// components/IntroWrapper.js
'use client';
import { useEffect, useState } from 'react';
import IntroScene from './IntroScene';

const reveal = () => document.documentElement.classList.remove('intro-pending');

export default function IntroWrapper({ children }) {
  const [showIntro, setShowIntro] = useState(false);

  useEffect(() => {
    let seen = false;
    try { seen = !!localStorage.getItem('hawiya_intro_seen'); } catch {}
    if (seen) reveal();
    else setShowIntro(true);
  }, []);

  return (
    <>
      {showIntro && (
        <IntroScene onReveal={reveal} onDone={() => { reveal(); setShowIntro(false); }} />
      )}
      {/* المحتوى يُرسم من الخادم دائماً؛ يُعطَّل فقط أثناء المقدمة */}
      <div inert={showIntro ? '' : undefined} aria-hidden={showIntro || undefined}>
        {children}
      </div>
    </>
  );
}
