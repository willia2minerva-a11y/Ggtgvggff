// components/IntroScene.js
'use client';
import { useEffect, useMemo, useRef, useState } from 'react';

const INTRO_TEXT = 'مرحباً أيها الساقط في الهاوية';
const markSeen = () => { try { localStorage.setItem('hawiya_intro_seen', '1'); } catch {} };

export default function IntroScene({ onDone, onReveal }) {
  const [stage, setStage] = useState('idle');
  const [text, setText] = useState('');
  const [showButton, setShowButton] = useState(false);
  const [fade, setFade] = useState(false);
  const [skipVisible, setSkipVisible] = useState(false);
  const timers = useRef([]);
  const typing = useRef(null);

  // النجوم تُولَّد مرة واحدة (كانت تقفز مع كل حرف يُكتب)
  const stars = useMemo(
    () => Array.from({ length: 40 }, () => ({
      top: Math.random() * 100, left: Math.random() * 100,
      delay: Math.random() * 4, opacity: 0.2 + Math.random() * 0.6
    })), []
  );

  useEffect(() => {
    const at = (fn, ms) => timers.current.push(setTimeout(fn, ms));
    at(() => setStage('star'), 300);
    at(() => setStage('burst'), 900);
    at(() => setStage('fall'), 1300);
    at(() => setStage('impact'), 2600);
    at(() => setStage('shake'), 2700);
    at(() => setStage('silent'), 3100);
    at(() => {
      setStage('text');
      let i = 0;
      typing.current = setInterval(() => {
        i++;
        setText(INTRO_TEXT.slice(0, i));
        if (i >= INTRO_TEXT.length) {
          clearInterval(typing.current);
          typing.current = null;
          setShowButton(true);
        }
      }, 50);
    }, 3600);
    at(() => setSkipVisible(true), 1000);

    return () => {
      timers.current.forEach(clearTimeout);
      if (typing.current) clearInterval(typing.current);
    };
  }, []);

  const handleEnter = () => {
    setFade(true);
    onReveal?.();
    timers.current.push(setTimeout(() => { markSeen(); onDone(); }, 700));
  };
  const handleSkip = () => { markSeen(); onDone(); };

  const falling = ['burst', 'fall', 'impact', 'shake', 'silent', 'text'].includes(stage);
  const isFall = stage === 'fall';
  // العنصر يُركَّب في burst (فوق الشاشة) ثم ينتقل في fall — فيعمل الـ transition فعلاً
  const pos = stage === 'burst'
    ? { top: '8%', transform: 'scale(0.3) rotate(0deg)', opacity: 0, filter: 'blur(4px)' }
    : isFall
      ? { top: '42%', transform: 'scale(0.6) rotate(360deg)', opacity: 1, filter: 'blur(3px)' }
      : { top: '44%', transform: 'scale(1) rotate(0deg)', opacity: 1, filter: 'none' };

  return (
    <div className={`fixed inset-0 z-50 bg-black flex items-center justify-center overflow-hidden transition-opacity duration-700 ${fade ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}>
      <div className="absolute inset-0 pointer-events-none">
        {stars.map((s, i) => (
          <div key={i} className="absolute w-[2px] h-[2px] bg-white rounded-full animate-flicker"
            style={{ top: `${s.top}%`, left: `${s.left}%`, animationDelay: `${s.delay}s`, opacity: s.opacity }} />
        ))}
      </div>

      {stage === 'star' && (
        <div className="absolute w-3 h-3 bg-white rounded-full animate-ping shadow-[0_0_30px_10px_rgba(255,255,255,0.7)]" />
      )}
      {stage === 'burst' && (
        <>
          <div className="absolute w-40 h-40 bg-amber-400 rounded-full blur-3xl opacity-60 animate-ping" />
          <div className="absolute w-72 h-72 bg-amber-500 rounded-full blur-3xl opacity-30 animate-ping" />
        </>
      )}

      {falling && (
        <div className="absolute inset-x-0 flex justify-center"
          style={{ top: pos.top, transition: `top ${isFall ? 1200 : 150}ms ${isFall ? 'ease-in' : 'ease-out'}` }}>
          <div className="relative" style={{
            transform: pos.transform, opacity: pos.opacity, filter: pos.filter,
            transition: `all ${isFall ? 1200 : 150}ms ${isFall ? 'ease-in' : 'ease-out'}`
          }}>
            {(stage === 'impact' || stage === 'shake') && (
              <div className="absolute inset-0 -m-8 bg-amber-400 rounded-full blur-3xl opacity-50 animate-ping" />
            )}
            <img src="/san/fallen.png" alt="الساقط"
              className="h-[26vh] max-h-56 w-auto pixelated select-none" draggable={false}
              onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = '/san/normal.png'; }} />
          </div>
        </div>
      )}

      {(stage === 'text' || showButton) && (
        <div className="absolute inset-x-0 bottom-[8%] z-10 text-center px-6">
          <h1 className="text-3xl sm:text-4xl font-bold font-pixel title-glow leading-relaxed mb-6 min-h-[5rem]">
            {text}
            {text.length < INTRO_TEXT.length && <span className="inline-block text-glow animate-blink ms-1">▮</span>}
          </h1>
          {showButton && (
            <button onClick={handleEnter} className="btn btn-glow text-lg px-10 py-4 animate-riseIn animate-bluePulse">
              ▸ ادخل الهاوية
            </button>
          )}
        </div>
      )}

      {skipVisible && !fade && (
        <button onClick={handleSkip}
          className="absolute top-4 end-4 text-ash hover:text-white text-sm py-2 px-3 transition-colors animate-riseIn">
          تخطي ▸
        </button>
      )}
    </div>
  );
}
