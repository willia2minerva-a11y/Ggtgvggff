// components/AdminPanel.js
'use client';
import { useEffect, useState } from 'react';

export default function AdminPanel() {
  const [tab, setTab] = useState('secrets');
  const [secrets, setSecrets] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState(null);

  const [form, setForm] = useState({
    word: '',
    reply: '',
    mood: 'secret',
    rewardPoints: 10,
    rewardSouls: 0,
    maxUses: 0,
    aliases: '',
  });

  const flash = (text, type = 'ok') => {
    setMsg({ text, type });
    setTimeout(() => setMsg(null), 2500);
  };

  const load = async () => {
    setLoading(true);
    try {
      const [s, u] = await Promise.all([
        fetch('/api/admin/secrets').then((r) => r.json()),
        fetch('/api/admin/users').then((r) => r.json()),
      ]);
      if (s.list) setSecrets(s.list);
      if (u.users) setUsers(u.users);
    } catch {}
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const addSecret = async (e) => {
    e.preventDefault();
    const res = await fetch('/api/admin/secrets', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    });
    const data = await res.json();
    if (!res.ok) return flash(data.error, 'err');
    flash('✅ تمت الإضافة');
    setForm({
      word: '',
      reply: '',
      mood: 'secret',
      rewardPoints: 10,
      rewardSouls: 0,
      maxUses: 0,
      aliases: '',
    });
    load();
  };

  const delSecret = async (id) => {
    if (!confirm('حذف الكلمة؟')) return;
    await fetch('/api/admin/secrets', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id }),
    });
    flash('🗑️ حُذفت');
    load();
  };

  const userAction = async (id, action, value = 0, reason = '') => {
    const res = await fetch('/api/admin/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, action, value, reason }),
    });
    if (res.ok) flash('✅ تم');
    else flash('❌ فشل', 'err');
    load();
  };

  const moodOptions = [
    { value: 'secret', label: '✨ سر' },
    { value: 'normal', label: '💀 عادي' },
    { value: 'laugh', label: '😄 ضحك' },
    { value: 'angry', label: '😠 غضب' },
    { value: 'sad', label: '😔 حزن' },
    { value: 'surprise', label: '😲 مفاجأة' },
    { value: 'scary', label: '👹 مرعب' },
  ];

  return (
    <div className="space-y-4">
      {/* ═══ العنوان ═══ */}
      <div className="panel panel-glow p-4 text-center">
        <h1 className="text-2xl font-bold title-glow font-pixel">
          ⚙️ لوحة الإدارة
        </h1>
        <p className="text-ash text-xs mt-1 font-pixel">تحكم كامل بالهاوية</p>
      </div>

      {/* ═══ التبويبات ═══ */}
      <div className="grid grid-cols-2 gap-2">
        <button
          onClick={() => setTab('secrets')}
          className={`panel p-3 flex items-center justify-center gap-2 transition-all active:scale-95 ${
            tab === 'secrets' ? 'border-glow shadow-[0_0_15px_rgba(212,175,55,0.4)]' : 'opacity-60'
          }`}
        >
          <span className="text-xl icon-pulse">🔑</span>
          <span className="font-pixel text-xs">الكلمات</span>
        </button>
        <button
          onClick={() => setTab('users')}
          className={`panel p-3 flex items-center justify-center gap-2 transition-all active:scale-95 ${
            tab === 'users' ? 'border-glow shadow-[0_0_15px_rgba(212,175,55,0.4)]' : 'opacity-60'
          }`}
        >
          <span className="text-xl icon-jump">👥</span>
          <span className="font-pixel text-xs">الأعضاء</span>
        </button>
      </div>

      {/* ═══ إشعار ═══ */}
      {msg && (
        <div
          className={`panel p-3 text-center text-sm font-pixel animate-riseIn border-2 ${
            msg.type === 'err' ? 'border-blood text-blood' : 'border-glow text-glow'
          }`}
        >
          {msg.text}
        </div>
      )}

      {/* ═══ تبويب الكلمات ═══ */}
      {tab === 'secrets' && (
        <>
          <form onSubmit={addSecret} className="panel p-4 space-y-3 animate-riseIn">
            <h3 className="font-bold text-glow font-pixel flex items-center gap-2 mb-2">
              <span className="icon-pulse">➕</span> كلمة سرية جديدة
            </h3>

            <input
              className="input"
              placeholder="الكلمة (بالإنجليزية أو العربية)"
              value={form.word}
              onChange={(e) => setForm({ ...form, word: e.target.value })}
              required
            />

            <input
              className="input"
              placeholder="صيغ بديلة (مفصولة بفاصلة)"
              value={form.aliases}
              onChange={(e) => setForm({ ...form, aliases: e.target.value })}
            />

            <textarea
              className="input"
              rows={2}
              placeholder="رد سانس على الكلمة"
              value={form.reply}
              onChange={(e) => setForm({ ...form, reply: e.target.value })}
              required
            />

            <select
              className="input"
              value={form.mood}
              onChange={(e) => setForm({ ...form, mood: e.target.value })}
            >
              {moodOptions.map((m) => (
                <option key={m.value} value={m.value} className="bg-black">
                  {m.label}
                </option>
              ))}
            </select>

            <div className="grid grid-cols-3 gap-2">
              <input
                className="input text-center"
                type="number"
                placeholder="نقاط"
                value={form.rewardPoints}
                onChange={(e) => setForm({ ...form, rewardPoints: e.target.value })}
              />
              <input
                className="input text-center"
                type="number"
                placeholder="أرواح"
                value={form.rewardSouls}
                onChange={(e) => setForm({ ...form, rewardSouls: e.target.value })}
              />
              <input
                className="input text-center"
                type="number"
                placeholder="حد"
                value={form.maxUses}
                onChange={(e) => setForm({ ...form, maxUses: e.target.value })}
              />
            </div>

            <button type="submit" className="btn btn-glow w-full font-pixel">
              ▸ إضافة الكلمة
            </button>
          </form>

          <div className="space-y-2">
            {loading && <p className="text-ash text-center text-sm font-pixel">…</p>}
            {!loading && secrets.length === 0 && (
              <div className="panel p-6 text-center text-ash font-pixel text-sm">
                لا كلمات سرية بعد
              </div>
            )}
            {secrets.map((s, i) => (
              <div key={s._id} className="panel p-3 flex justify-between items-center animate-riseIn">
                <div className="min-w-0 flex-1">
                  <div className="text-glow font-pixel text-sm truncate">
                    🔑 {s.word}
                  </div>
                  <div className="text-ash text-[10px] font-pixel mt-1">
                    {s.rewardPoints} نقطة · {s.rewardSouls} أرواح · استُخدم {s.usedBy?.length || 0}
                    {s.maxUses > 0 ? `/${s.maxUses}` : ' (∞)'}
                  </div>
                </div>
                <button
                  className="btn btn-danger text-xs py-1 px-3 shrink-0"
                  onClick={() => delSecret(s._id)}
                >
                  حذف
                </button>
              </div>
            ))}
          </div>
        </>
      )}

      {/* ═══ تبويب الأعضاء ═══ */}
      {tab === 'users' && (
        <div className="space-y-2">
          {loading && <p className="text-ash text-center text-sm font-pixel">…</p>}
          {users.map((u) => (
            <div key={u._id} className="panel p-3 animate-riseIn">
              <div className="flex justify-between items-start mb-2">
                <div className="min-w-0">
                  <div className="font-bold font-pixel text-sm truncate">
                    {u.displayName || u.username}
                  </div>
                  <div className="text-ash text-[10px] font-pixel truncate">
                    @{u.username} · {u.points} نقطة · {u.souls} روح
                  </div>
                </div>
                <div className="flex gap-1 shrink-0">
                  {u.isAdmin && <span className="text-glow text-xs">⚙️</span>}
                  {u.inGrave && <span className="text-blood text-xs animate-flicker">⚰️</span>}
                </div>
              </div>
              <div className="flex flex-wrap gap-1">
                <button
                  className="btn text-[10px] py-1 px-2"
                  onClick={() => userAction(u._id, 'addPoints', 10)}
                >
                  +10⚡
                </button>
                <button
                  className="btn text-[10px] py-1 px-2"
                  onClick={() => userAction(u._id, 'addSouls', 10)}
                >
                  +10❤
                </button>
                <button
                  className="btn text-[10px] py-1 px-2"
                  onClick={() => userAction(u._id, 'addSouls', -10)}
                >
                  -10❤
                </button>
                {!u.inGrave ? (
                  <button
                    className="btn btn-danger text-[10px] py-1 px-2"
                    onClick={() => userAction(u._id, 'grave', 0, 'قرار إداري')}
                  >
                    ⚰️ للمقبرة
                  </button>
                ) : (
                  <button
                    className="btn btn-glow text-[10px] py-1 px-2"
                    onClick={() => userAction(u._id, 'revive')}
                  >
                    ✨ إحياء
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
        }
